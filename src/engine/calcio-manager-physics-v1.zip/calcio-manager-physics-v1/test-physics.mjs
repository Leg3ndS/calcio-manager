import { updateAllPlayerMovement } from './movement/playerMovement.js';
import { launchBall, updateBallPhysics } from './physics/ballPhysics.js';

const p = { id:'p1', role:'mezzala', side:'home', onPitch:true, position:{x:.4,y:.5}, targetPosition:{x:.7,y:.5}, attributes:{physical:{accelerazione:90,velocita:85,agilita:80,resistenza:90,forza:70,equilibrio:80,reattivita:80}} };
const q = { id:'q1', role:'difensore centrale', side:'away', onPitch:true, position:{x:.7,y:.5}, targetPosition:{x:.65,y:.5}, attributes:{physical:{accelerazione:50,velocita:50,agilita:50,resistenza:80,forza:80,equilibrio:60,reattivita:60}} };
const ball={x:.4,y:.5,velocityX:0,velocityY:0,height:0,ownerId:'p1',state:'controlled'};
const start=p.position.x;
updateAllPlayerMovement({homePlayers:[p],awayPlayers:[q],ball,deltaSimulationSeconds:1});
if (!(p.position.x > start && p.position.x < .71)) throw new Error('player movement failed');
if (!p.physics || !Number.isFinite(p.physics.speed)) throw new Error('player physics missing');
ball.ownerId=null;
launchBall({ball,from:{x:.4,y:.5},to:{x:.8,y:.5},speed:.4});
const before=ball.x; updateBallPhysics(ball,.1);
if (!(ball.x>before)) throw new Error('ball physics failed');
console.log('PHYSICS TEST OK', {playerX:p.position.x, playerSpeed:p.physics.speed, ballX:ball.x});
